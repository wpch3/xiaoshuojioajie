import PyPDF2
import os

def extract_text_from_pdf(pdf_path):
    text = ""
    try:
        with open(pdf_path, 'rb') as file:
            pdf_reader = PyPDF2.PdfReader(file)
            for page_num in range(len(pdf_reader.pages)):
                page = pdf_reader.pages[page_num]
                text += page.extract_text() + "\n"
    except Exception as e:
        text = f"Error reading {pdf_path}: {str(e)}"
    return text

# 读取第一个PDF
pdf1_path = "/home/user/uploads/阿尔萨斯同人小说开局构思.pdf"
pdf1_text = extract_text_from_pdf(pdf1_path)

# 读取第二个PDF
pdf2_path = "/home/user/uploads/真龙的艾泽拉斯史诗冒险.pdf"
pdf2_text = extract_text_from_pdf(pdf2_path)

# 保存到文本文件
with open("/home/user/pdf1_content.txt", "w", encoding="utf-8") as f:
    f.write(pdf1_text)

with open("/home/user/pdf2_content.txt", "w", encoding="utf-8") as f:
    f.write(pdf2_text)

print("PDF文本提取完成！")
print(f"PDF1长度: {len(pdf1_text)} 字符")
print(f"PDF2长度: {len(pdf2_text)} 字符")